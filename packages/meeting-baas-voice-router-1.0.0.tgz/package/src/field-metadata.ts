// Re-export field metadata from voice-router-dev SDK for UI form generation
// Lightweight pre-computed metadata — no Zod dependency
export type { FieldMetadata, FieldType, FieldMetadataProvider } from "voice-router-dev/field-metadata"

export {
  PROVIDER_FIELDS,
  GLADIA_TRANSCRIPTION_FIELDS,
  DEEPGRAM_TRANSCRIPTION_FIELDS,
  ASSEMBLYAI_TRANSCRIPTION_FIELDS,
  SPEECHMATICS_TRANSCRIPTION_FIELDS,
  SONIOX_TRANSCRIPTION_FIELDS,
} from "voice-router-dev/field-metadata"
