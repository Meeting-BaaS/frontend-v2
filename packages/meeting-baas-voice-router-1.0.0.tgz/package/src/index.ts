// Common types
export type { Provider, BatchProvider, StreamingProvider, ApiKeyConfig, TranscriptWord, Logger } from "./types/common"
export { PROVIDERS, BATCH_PROVIDERS, STREAMING_PROVIDERS, PROVIDER_DISPLAY_NAMES, PROVIDER_NAME_MAP, PROVIDER_ENV_KEY_MAP, resolveProviderName, defaultLogger } from "./types/common"

// Streaming types
export type {
  AudioEncoding,
  StreamingConfig,
  StreamingSession,
  StreamingCallbacks,
  ProviderMetadata,
  ProviderStreamingOptions,
  DeepgramStreamingOptions,
  GladiaStreamingOptions,
  AssemblyAIStreamingOptions,
  SpeechmaticsStreamingOptions,
  SonioxStreamingOptions,
  HandshakeMessage,
  SpeakerData,
  ProviderAudioConfig
} from "./types/streaming"
export { PROVIDER_AUDIO_CONFIG } from "./types/streaming"

// Async/batch types
export type {
  BatchTranscriptionOptions,
  BatchTranscriptionResult,
  BatchTranscriptionSuccess,
  BatchTranscriptionFailure,
  BatchUtterance,
  WebhookProvider,
  SubmitBatchResult
} from "./types/async"
export { WEBHOOK_PROVIDERS } from "./types/async"

// Provider functions
export { createStreamingSession, runBatchTranscription } from "./providers/factory"
export { startStreamingSession } from "./providers/streaming/base"
export { transcribeBatch } from "./providers/async/base"
export { submitBatchTranscription } from "./providers/async/submit"
export { parseWebhookCallback } from "./providers/async/parse-webhook"
export { startStubStreamingSession } from "./providers/streaming/stub"
export { transcribeBatchStub } from "./providers/async/stub"

// Streaming options utilities
export { buildStreamingOptions, unflattenKeys, toGladiaEncoding } from "./providers/streaming/options"

// Provider adapter (for transcript management: get, delete, list)
export { createAdapter } from "./providers/adapter"
export type { AdapterType } from "./providers/adapter"

// SDK validation (lazy-loaded — batch/transcription only)
export { validateTranscriptionConfigAsync, preloadSdkSchemas, isSdkLoaded } from "./schemas/validate-custom-params"
export type { ValidationResult, FieldValidationError } from "./schemas/validate-custom-params"

// Field metadata is available via '@meeting-baas/voice-router/field-metadata' subpath export
// (separate entry point to avoid bundling heavy SDK modules in frontend)
