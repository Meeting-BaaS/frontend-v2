// Common types
export type { Provider, BatchProvider, StreamingProvider, BatchApiKeyConfig, StreamingApiKeyConfig, BatchProviderRegionMap, StreamingProviderRegionMap, TranscriptWord, Logger } from "./types/common"
export { PROVIDERS, BATCH_PROVIDERS, STREAMING_PROVIDERS, BATCH_PROVIDER_REGIONS, STREAMING_PROVIDER_REGIONS, DEFAULT_BATCH_REGION, DEFAULT_STREAMING_REGION, PROVIDER_DISPLAY_NAMES, PROVIDER_NAME_MAP, PROVIDER_ENV_KEY_MAP, resolveProviderName, buildBatchApiKeyConfig, buildStreamingApiKeyConfig, defaultLogger } from "./types/common"

// Streaming types
export type {
  AudioEncoding,
  StreamingConfig,
  StreamingSession,
  StreamingCallbacks,
  ProviderMetadata,
  ProviderStreamingOptions,
  DeepgramStreamingOptions,
  GladiaStreamingOptions,
  AssemblyAIStreamingOptions,
  SpeechmaticsStreamingOptions,
  SonioxStreamingOptions,
  HandshakeMessage,
  SpeakerData,
  ProviderAudioConfig
} from "./types/streaming"
export { PROVIDER_AUDIO_CONFIG } from "./types/streaming"

// Async/batch types
export type {
  BatchTranscriptionOptions,
  BatchTranscriptionResult,
  BatchTranscriptionSuccess,
  BatchTranscriptionFailure,
  BatchUtterance,
  SubmitBatchResult
} from "./types/async"

// Provider functions
export { createStreamingSession } from "./providers/factory"
export { startStreamingSession } from "./providers/streaming/base"
export { submitBatchTranscription } from "./providers/async/submit"
export { parseWebhookCallback } from "./providers/async/parse-webhook"
export { startStubStreamingSession } from "./providers/streaming/stub"

// Streaming options utilities
export { buildStreamingOptions, unflattenKeys, toGladiaEncoding } from "./providers/streaming/options"

// Provider adapter (for transcript management: get, delete, list)
export { createAdapter } from "./providers/adapter"
export type { AdapterType } from "./providers/adapter"

// SDK validation (lazy-loaded — batch/transcription only)
export { validateTranscriptionConfigAsync, preloadSdkSchemas, isSdkLoaded } from "./schemas/validate-custom-params"
export type { ValidationResult, FieldValidationError } from "./schemas/validate-custom-params"

// Field metadata is available via '@meeting-baas/voice-router/field-metadata' subpath export
// (separate entry point to avoid bundling heavy SDK modules in frontend)
