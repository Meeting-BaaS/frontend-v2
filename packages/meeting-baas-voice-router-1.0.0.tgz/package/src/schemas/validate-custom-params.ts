/**
 * Provider config validation with lazy-loaded SDK schemas
 *
 * SDK Zod schemas are ~46k lines of complex nested types that cause OOM during
 * TypeScript compilation. This module uses dynamic imports to load them at
 * runtime only, avoiding compile-time type resolution.
 *
 * Only exports batch (transcription) validators — streaming validation is
 * handled in the voice-router sidecar.
 */

import { z } from "zod"

// ==================== Types (defined locally, not imported from SDK) ====================

/** Validation error for a specific field */
export interface FieldValidationError {
  /** Field path (e.g., "encoding", "model") */
  field: string
  /** Human-readable error message */
  message: string
  /** Zod error code for programmatic handling */
  code: string
}

/** Validation result */
export interface ValidationResult {
  /** Whether the config is valid */
  success: boolean
  /** Array of validation errors (empty if success) */
  errors: FieldValidationError[]
  /** Validated data (undefined if validation failed) */
  data?: Record<string, unknown> | undefined
}

// ==================== SDK Schema Cache (lazy-loaded) ====================

/** Cached SDK module - loaded once on first validation call */
let sdkSchemaModule: SdkSchemaCache | null = null
let sdkLoadPromise: Promise<SdkSchemaCache> | null = null

/** Minimal interface for the SDK schemas we use (avoids importing SDK types) */
interface SdkSchemaCache {
  transcriptionSchemas: Record<string, z.ZodSchema>
}

/** Expected named exports from the SDK field-configs module */
interface SdkFieldConfigExports {
  GladiaTranscriptionSchema: z.ZodSchema
  DeepgramTranscriptionSchema: z.ZodSchema
  AssemblyAITranscriptionSchema: z.ZodSchema
  SpeechmaticsTranscriptionSchema: z.ZodSchema
  SonioxTranscriptionSchema: z.ZodSchema
}

/**
 * Fields managed by the pipeline, not the user — skip "Required" errors for these.
 * These are set by the server (audio_url, webhook_url) or by the SDK adapter
 * (speech_models is mapped from options.model by the AssemblyAI adapter).
 */
const PIPELINE_MANAGED_FIELDS = new Set([
  "audio_url",
  "audio_data",
  "file",
  "webhook_url",
  "speech_models"
])

/**
 * Lazy-load SDK schemas (only called at runtime, not compile time)
 * Uses dynamic import to avoid TypeScript evaluating 46k lines of Zod types
 */
async function loadSdkSchemas(): Promise<SdkSchemaCache> {
  if (sdkSchemaModule) {
    return sdkSchemaModule
  }

  if (sdkLoadPromise) {
    return sdkLoadPromise
  }

  sdkLoadPromise = (async () => {
    // Dynamic import — TypeScript won't evaluate these types at compile time.
    // We cast through `unknown` to a local interface describing only the exports
    // we use, avoiding `any` while keeping the build safe from SDK OOM.
    const sdk = await import("voice-router-dev/field-configs" as never) as unknown as SdkFieldConfigExports

    const cache: SdkSchemaCache = {
      transcriptionSchemas: {
        gladia: sdk.GladiaTranscriptionSchema,
        deepgram: sdk.DeepgramTranscriptionSchema,
        assemblyai: sdk.AssemblyAITranscriptionSchema,
        speechmatics: sdk.SpeechmaticsTranscriptionSchema,
        soniox: sdk.SonioxTranscriptionSchema
      }
    }

    sdkSchemaModule = cache
    return cache
  })()

  return sdkLoadPromise
}

/**
 * Check if SDK schemas are loaded
 */
export function isSdkLoaded(): boolean {
  return sdkSchemaModule !== null
}

/**
 * Pre-load SDK schemas (call this at app startup for faster first validation)
 */
export async function preloadSdkSchemas(): Promise<void> {
  await loadSdkSchemas()
}

// ==================== Validation Helpers ====================

/**
 * Format Zod error into field validation errors.
 * When skipServerFields is true, filters out "Required" errors for fields
 * that are provided by the server (audio_url, file, etc.), not the user.
 */
function formatZodError(error: z.ZodError, skipServerFields = false): FieldValidationError[] {
  return error.issues
    .filter((issue: z.core.$ZodIssue) => {
      if (skipServerFields && issue.code === "invalid_type") {
        const field = issue.path[0]?.toString() ?? ""
        if (PIPELINE_MANAGED_FIELDS.has(field)) {
          return false
        }
      }
      return true
    })
    .map((issue: z.core.$ZodIssue) => ({
      field: issue.path.map(String).join(".") || "config",
      message: issue.message,
      code: issue.code ?? "unknown"
    }))
}

// ==================== Async Validation ====================

/**
 * Validate transcription (batch) provider config with full SDK schemas.
 * Lazy-loads SDK on first call, then uses cached schemas.
 *
 * - Skips "Required" errors for server-provided fields (audio_url, etc.)
 * - Rejects unknown providers (no schema = error, not passthrough)
 */
export async function validateTranscriptionConfigAsync(
  provider: string,
  config: Record<string, unknown>
): Promise<ValidationResult> {
  const sdk = await loadSdkSchemas()
  const schema = sdk.transcriptionSchemas[provider]

  if (!schema) {
    return {
      success: false,
      errors: [
        {
          field: "provider",
          message: `Unknown transcription provider: '${provider}'. Supported providers: gladia, deepgram, assemblyai, speechmatics, soniox`,
          code: "invalid_enum_value"
        }
      ]
    }
  }

  const result = schema.safeParse(config)

  if (result.success) {
    return { success: true, errors: [], data: result.data as Record<string, unknown> }
  }

  const errors = formatZodError(result.error, true)

  return {
    success: errors.length === 0,
    errors,
    data: errors.length === 0 ? config : undefined
  }
}
