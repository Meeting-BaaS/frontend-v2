/**
 * Lightweight re-export of provider constants and types.
 *
 * Use this subpath (`@meeting-baas/voice-router/providers`) in frontends
 * to avoid pulling in the voice-router-dev SDK. All exports come from
 * `providers-public.ts` which has zero SDK imports.
 */
export type { Provider, BatchProvider, StreamingProvider } from "./types/providers-public"
export {
  PROVIDERS,
  BATCH_PROVIDERS,
  STREAMING_PROVIDERS,
  BATCH_PROVIDER_REGIONS,
  STREAMING_PROVIDER_REGIONS,
  PROVIDER_DISPLAY_NAMES
} from "./types/providers-public"
