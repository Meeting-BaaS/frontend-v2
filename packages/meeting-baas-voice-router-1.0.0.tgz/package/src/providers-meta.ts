/**
 * Lightweight re-export of provider constants and types.
 * Use this subpath (@meeting-baas/voice-router/providers) in frontends
 * to avoid pulling in heavy SDK dependencies.
 */
export type { Provider, BatchProvider, StreamingProvider } from "./types/common"
export { PROVIDERS, BATCH_PROVIDERS, STREAMING_PROVIDERS, PROVIDER_DISPLAY_NAMES } from "./types/common"
