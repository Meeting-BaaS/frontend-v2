import { VoiceRouter } from "voice-router-dev"
import type { ProviderConfig } from "voice-router-dev"
import type { Provider, StreamingProvider, ApiKeyConfig, TranscriptWord, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type { BatchTranscriptionOptions, BatchTranscriptionResult, BatchUtterance } from "@/types/async"
import { createAdapter } from "@/providers/adapter"
import { unflattenKeys } from "@/providers/streaming/options"

// Effectively disables the SDK's default 60s HTTP timeout for long batch jobs.
const BATCH_HTTP_TIMEOUT_MS = 24 * 60 * 60 * 1000

/**
 * Extract word-level data from batch transcription result.
 * Handles providers that return words at different nesting levels.
 */
function extractBatchWords(result: Record<string, unknown>): TranscriptWord[] | undefined {
  const data = result["data"] as Record<string, unknown> | undefined
  if (!data) return undefined

  // Direct words array
  const directWords = data["words"]
  if (Array.isArray(directWords) && directWords.length > 0) {
    return directWords.map((w: Record<string, unknown>) => {
      const word: TranscriptWord = {
        text: String(w["text"] ?? w["word"] ?? ""),
        start: Number(w["start"] ?? 0),
        end: Number(w["end"] ?? 0)
      }
      if (typeof w["confidence"] === "number") word.confidence = w["confidence"]
      if (typeof w["speaker"] === "string") word.speaker = w["speaker"]
      return word
    })
  }

  // Words nested in utterances
  const utterances = data["utterances"] as Array<Record<string, unknown>> | undefined
  if (Array.isArray(utterances)) {
    const words: TranscriptWord[] = []
    for (const utt of utterances) {
      const uttWords = utt["words"] as Array<Record<string, unknown>> | undefined
      if (Array.isArray(uttWords)) {
        for (const w of uttWords) {
          const word: TranscriptWord = {
            text: String(w["text"] ?? w["word"] ?? ""),
            start: Number(w["start"] ?? 0),
            end: Number(w["end"] ?? 0)
          }
          if (typeof w["confidence"] === "number") word.confidence = w["confidence"]
          if (typeof w["speaker"] === "string") word.speaker = w["speaker"]
          words.push(word)
        }
      }
    }
    if (words.length > 0) return words
  }

  return undefined
}

/**
 * Extract utterance-level data from batch transcription result.
 * Handles providers that return utterances at different nesting levels.
 */
function extractBatchUtterances(result: Record<string, unknown>): BatchUtterance[] | undefined {
  const data = result["data"] as Record<string, unknown> | undefined
  if (!data) return undefined

  const utterances = data["utterances"] as Array<Record<string, unknown>> | undefined
  if (!Array.isArray(utterances) || utterances.length === 0) return undefined

  return utterances.map((utt) => {
    const words: TranscriptWord[] = []
    const uttWords = utt["words"] as Array<Record<string, unknown>> | undefined
    if (Array.isArray(uttWords)) {
      for (const w of uttWords) {
        const word: TranscriptWord = {
          text: String(w["text"] ?? w["word"] ?? ""),
          start: Number(w["start"] ?? 0),
          end: Number(w["end"] ?? 0)
        }
        if (typeof w["confidence"] === "number") word.confidence = w["confidence"]
        if (typeof w["speaker"] === "string") word.speaker = w["speaker"]
        words.push(word)
      }
    }

    const utterance: BatchUtterance = {
      text: String(utt["text"] ?? ""),
      start: Number(utt["start"] ?? 0),
      end: Number(utt["end"] ?? 0),
      words
    }
    if (typeof utt["confidence"] === "number") utterance.confidence = utt["confidence"]
    if (typeof utt["channel"] === "number") utterance.channel = utt["channel"]
    if (typeof utt["speaker"] === "number" || typeof utt["speaker"] === "string") {
      utterance.speaker = utt["speaker"] as number | string
    }
    if (typeof utt["language"] === "string") utterance.language = utt["language"]
    return utterance
  })
}

/**
 * Extract audio duration from batch transcription result metadata.
 */
function extractAudioDuration(result: Record<string, unknown>): number | undefined {
  const data = result["data"] as Record<string, unknown> | undefined
  if (!data) return undefined
  const metadata = data["metadata"] as Record<string, unknown> | undefined
  if (!metadata) return undefined
  const duration = metadata["audio_duration"]
  return typeof duration === "number" ? duration : undefined
}

/**
 * Redact sensitive fields from error objects before logging.
 */
function sanitizeErrorForLogging(err: unknown): unknown {
  if (err === null || err === undefined) return err
  if (typeof err !== "object") return err

  const obj = err as Record<string, unknown>
  const sanitized: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(obj)) {
    if (key === "config" || key === "request" || key === "headers") continue
    if (key === "response" && typeof value === "object" && value !== null) {
      const resp = value as Record<string, unknown>
      sanitized[key] = { status: resp["status"], statusText: resp["statusText"], data: resp["data"] }
    } else {
      sanitized[key] = value
    }
  }
  return sanitized
}

function extractAxiosError(e: unknown): { httpStatus?: number | undefined; responseMessage?: string | undefined } {
  if (typeof e !== "object" || e === null || !("response" in e)) return {}
  const resp = (e as Record<string, unknown>)["response"]
  if (typeof resp !== "object" || resp === null) return {}
  const respObj = resp as Record<string, unknown>
  const httpStatus = typeof respObj["status"] === "number" ? respObj["status"] : undefined
  let responseMessage: string | undefined
  const data = respObj["data"]
  if (typeof data === "string") {
    // Some providers return error as plain string body
    responseMessage = data
  } else if (typeof data === "object" && data !== null) {
    const dataObj = data as Record<string, unknown>
    // Try common error response fields: message, error, detail
    const msg = dataObj["message"] ?? dataObj["error"] ?? dataObj["detail"]
    responseMessage = typeof msg === "string" ? msg : undefined
    // Fallback: stringify the whole response body if no known field matched
    if (!responseMessage) {
      try { responseMessage = JSON.stringify(data) } catch { /* ignore */ }
    }
  }
  return { httpStatus, responseMessage }
}

function getErrorDetailMessage(details: unknown): string | undefined {
  if (typeof details !== "object" || details === null) return undefined
  const msg = (details as Record<string, unknown>)["message"]
  return typeof msg === "string" ? msg : undefined
}

/**
 * Transcribe an audio file via URL using the voice-router-dev SDK (batch/async).
 */
export async function transcribeBatch(
  url: string,
  provider: Provider,
  apiKeyConfig: ApiKeyConfig,
  options?: BatchTranscriptionOptions,
  logger?: Logger | undefined
): Promise<BatchTranscriptionResult> {
  const startTime = Date.now()

  const providerConfig: Record<string, ProviderConfig> = {
    [provider]: { apiKey: apiKeyConfig.apiKey, timeout: BATCH_HTTP_TIMEOUT_MS }
  }

  const router = new VoiceRouter({
    providers: providerConfig,
    selectionStrategy: "explicit"
  })

  // Register streaming adapter (needed for some providers' batch too)
  const adapter = createAdapter(provider as StreamingProvider, apiKeyConfig)
  if (adapter) {
    router.registerAdapter(adapter)
  }

  try {
    const transcribeOptions: Record<string, unknown> = {
      provider,
      // SDK unified diarization flag — maps to provider-specific fields
      // (e.g. speaker_labels for AssemblyAI, diarize for Deepgram).
      // Required so providers return utterance-level data.
      diarization: options?.diarization ?? true
    }

    if (options && Object.keys(options).length > 0) {
      const unflattened = unflattenKeys(options)
      // AssemblyAI: map deprecated speech_model (singular) → speech_models (plural array)
      // SDK 0.8.4+ uses speech_models; sending both causes a 400 error
      if (provider === "assemblyai" && "speech_model" in unflattened) {
        if (!("speech_models" in unflattened)) {
          unflattened["speech_models"] = [unflattened["speech_model"]]
        }
        delete unflattened["speech_model"]
      }
      transcribeOptions[provider] = unflattened
    }

    const _log = logger ?? defaultLogger
    _log.info({ provider, transcribeOptions: JSON.stringify(transcribeOptions), url: url.substring(0, 80) }, "DEBUG: calling router.transcribe")

    const result = await router.transcribe(
      { type: "url", url },
      transcribeOptions as Parameters<typeof router.transcribe>[1]
    )

    const elapsed = Date.now() - startTime
    const resultAny = result as unknown as Record<string, unknown>

    if (result.success) {
      const data = resultAny["data"] as Record<string, unknown> | undefined
      const tracking = resultAny["tracking"] as Record<string, unknown> | undefined
      const extended = resultAny["extended"] as Record<string, unknown> | undefined
      const speakers = data?.["speakers"] as Array<Record<string, unknown>> | undefined

      const successResult: BatchTranscriptionResult = {
        success: true,
        text: (data?.["text"] as string) ?? "",
        words: extractBatchWords(resultAny),
        utterances: extractBatchUtterances(resultAny),
        processingTimeMs: elapsed,
        rawProviderResponse: resultAny
      }

      const audioDuration = extractAudioDuration(resultAny)
      if (audioDuration !== undefined) successResult.audioDuration = audioDuration

      if (Array.isArray(speakers)) {
        successResult.speakers = speakers.map((s) => ({
          id: String(s["id"] ?? ""),
          name: typeof s["label"] === "string" ? s["label"] : undefined
        }))
      }

      const summary = data?.["summary"]
      if (typeof summary === "string") successResult.summary = summary

      const language = data?.["language"]
      if (typeof language === "string") successResult.language = language

      const trackingReqId = tracking?.["requestId"]
      const extendedReqId = extended?.["requestId"]
      if (typeof trackingReqId === "string") {
        successResult.providerJobId = trackingReqId
      } else if (typeof extendedReqId === "string") {
        successResult.providerJobId = extendedReqId
      }

      return successResult
    }

    const errorObj = resultAny["error"] as Record<string, unknown> | undefined
    const errorResult: BatchTranscriptionResult = {
      success: false,
      error: {
        code: "TRANSCRIPTION_FAILED",
        message: (errorObj?.["message"] as string) ?? "Unknown error"
      },
      processingTimeMs: elapsed
    }

    const statusCode = errorObj?.["statusCode"]
    if (typeof statusCode === "number") {
      errorResult.error.httpStatus = statusCode
    }

    const detailMsg = getErrorDetailMessage(errorObj?.["details"])
    if (detailMsg) {
      errorResult.error.responseMessage = detailMsg
    }

    return errorResult
  } catch (e) {
    const log = logger ?? defaultLogger
    log.error(
      { provider, error: e instanceof Error ? e.message : String(e), details: sanitizeErrorForLogging(e) },
      "Batch transcription error"
    )
    const { httpStatus, responseMessage } = extractAxiosError(e)

    const errorResult: BatchTranscriptionResult = {
      success: false,
      error: {
        code: "TRANSCRIPTION_ERROR",
        message: e instanceof Error ? e.message : "Unknown error"
      },
      processingTimeMs: Date.now() - startTime
    }

    if (httpStatus !== undefined) errorResult.error.httpStatus = httpStatus
    if (responseMessage !== undefined) errorResult.error.responseMessage = responseMessage

    return errorResult
  }
}
