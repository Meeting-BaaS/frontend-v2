import type { BatchApiKeyConfig, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type { BatchTranscriptionOptions, SubmitBatchResult } from "@/types/async"
import { createAdapter } from "@/providers/adapter"
import { unflattenKeys } from "@/providers/streaming/options"

/**
 * Submit a batch transcription job with a webhook callback URL.
 * The provider will call the webhook when transcription completes — this function
 * returns immediately with the provider's job ID (fire-and-forget).
 *
 * Uses the SDK adapter which handles region endpoints, auth headers, and
 * provider-specific request formatting automatically.
 *
 * Supported providers: gladia, assemblyai, deepgram, speechmatics, soniox.
 */
export async function submitBatchTranscription(
  audioUrl: string,
  config: BatchApiKeyConfig,
  webhookUrl: string,
  options?: BatchTranscriptionOptions,
  logger?: Logger | undefined
): Promise<SubmitBatchResult> {
  const log = logger ?? defaultLogger
  const provider = config.provider
  const adapter = createAdapter(config)
  if (!adapter) throw new Error(`No adapter for provider: ${provider}`)

  // Build SDK TranscribeOptions from our BatchTranscriptionOptions
  const transcribeOptions: Record<string, unknown> = { webhookUrl }
  if (options?.language) transcribeOptions["language"] = options.language
  if (options?.diarization !== undefined) transcribeOptions["diarization"] = options.diarization
  if (options?.model) transcribeOptions["model"] = options.model
  if (options?.summarization) transcribeOptions["summarization"] = options.summarization

  // Pass remaining custom params via provider-specific sub-object.
  // unflattenKeys converts dot-notated keys (e.g. "diarization_config.min_speakers")
  // into nested objects that the SDK adapter spreads into the provider request.
  if (options) {
    const standardKeys = new Set(["language", "diarization", "model", "summarization"])
    const customParams: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(options)) {
      if (!standardKeys.has(key)) customParams[key] = value
    }
    if (Object.keys(customParams).length > 0) {
      transcribeOptions[provider] = unflattenKeys(customParams)
    }
  }

  const result = await adapter.transcribe(
    { type: "url", url: audioUrl },
    transcribeOptions as never
  ) as { success: boolean; data?: { id: string }; error?: { message: string } }

  if (!result.success || !result.data?.id) {
    const msg = result.error?.message ?? "No job ID returned"
    log.error({ provider, error: msg }, "Batch submission failed")
    throw new Error(`${provider} submission failed: ${msg}`)
  }

  log.info({ provider, jobId: result.data.id }, "Batch transcription submitted via SDK")
  return { providerJobId: result.data.id }
}
