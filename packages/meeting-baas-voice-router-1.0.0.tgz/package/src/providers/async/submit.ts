import type { Provider, ApiKeyConfig, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type { BatchTranscriptionOptions, SubmitBatchResult } from "@/types/async"
import { unflattenKeys } from "@/providers/streaming/options"

/**
 * Submit a batch transcription job with a webhook callback URL.
 * The provider will call the webhook when transcription completes — this function
 * returns immediately with the provider's job ID (fire-and-forget).
 *
 * Supported providers: gladia, assemblyai, deepgram, speechmatics, soniox.
 */
export async function submitBatchTranscription(
  audioUrl: string,
  provider: Provider,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options?: BatchTranscriptionOptions,
  logger?: Logger | undefined
): Promise<SubmitBatchResult> {
  const log = logger ?? defaultLogger

  switch (provider) {
    case "gladia":
      return submitToGladia(audioUrl, apiKeyConfig, webhookUrl, options, log)
    case "assemblyai":
      return submitToAssemblyAI(audioUrl, apiKeyConfig, webhookUrl, options, log)
    case "deepgram":
      return submitToDeepgram(audioUrl, apiKeyConfig, webhookUrl, options, log)
    case "speechmatics":
      return submitToSpeechmatics(audioUrl, apiKeyConfig, webhookUrl, options, log)
    case "soniox":
      return submitToSoniox(audioUrl, apiKeyConfig, webhookUrl, options, log)
    default:
      throw new Error(`Unknown provider for webhook submission: ${provider}`)
  }
}

// ─── Gladia v2 ──────────────────────────────────────────────────────

async function submitToGladia(
  audioUrl: string,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options: BatchTranscriptionOptions | undefined,
  logger: Logger
): Promise<SubmitBatchResult> {
  const body: Record<string, unknown> = {
    audio_url: audioUrl,
    callback_url: webhookUrl
  }

  // Apply standard options
  if (options) {
    const unflattened = unflattenKeys(options)
    if (unflattened["diarization"] !== undefined) body["diarization"] = unflattened["diarization"]
    if (unflattened["language"] !== undefined) body["language"] = unflattened["language"]
    if (unflattened["summarization"] !== undefined) body["summarization"] = unflattened["summarization"]
    if (unflattened["diarization_config"]) body["diarization_config"] = unflattened["diarization_config"]
    // Pass through any provider-specific custom params (never allow callback URL override)
    for (const [key, value] of Object.entries(unflattened)) {
      if (!["diarization", "language", "summarization", "model", "diarization_config", "callback_url"].includes(key)) {
        body[key] = value
      }
    }
  }

  const response = await fetch("https://api.gladia.io/v2/transcription", {
    method: "POST",
    headers: {
      "x-gladia-key": apiKeyConfig.apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => "unknown error")
    logger.error({ provider: "gladia", status: response.status, error: errorText }, "Gladia submission failed")
    throw new Error(`Gladia submission failed (${response.status}): ${errorText}`)
  }

  const result = await response.json() as { id: string; result_url?: string }
  logger.info({ provider: "gladia", jobId: result.id }, "Gladia transcription job submitted")
  return { providerJobId: result.id }
}

// ─── AssemblyAI ─────────────────────────────────────────────────────

async function submitToAssemblyAI(
  audioUrl: string,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options: BatchTranscriptionOptions | undefined,
  logger: Logger
): Promise<SubmitBatchResult> {
  const body: Record<string, unknown> = {
    audio_url: audioUrl,
    webhook_url: webhookUrl
  }

  // Always request speaker labels so AssemblyAI returns utterance-level data.
  // SDK unified diarization flag defaults to true; callers can override via options.
  body["speaker_labels"] = options?.diarization !== false
  if (options?.language) body["language_code"] = options.language
  if (options?.summarization) body["summarization"] = true

  // Map model → speech_models (required array since AssemblyAI API v2 update)
  // User may also provide speech_models directly via custom params (handled below)
  if (options?.model) {
    body["speech_models"] = [options.model]
  }

  // Apply custom params (already dot-notated keys from user)
  // Filter out speech_model (singular) — SDK v0.8.4 schema has both speech_model and
  // speech_models; AssemblyAI rejects requests containing both. We map it to speech_models below.
  if (options) {
    const unflattened = unflattenKeys(options)
    for (const [key, value] of Object.entries(unflattened)) {
      if (!["diarization", "language", "summarization", "model", "webhook_url", "speech_model"].includes(key)) {
        body[key] = value
      }
    }
    // If user provided speech_model (singular) via custom params, map it to speech_models
    if (!body["speech_models"] && unflattened["speech_model"]) {
      const model = unflattened["speech_model"] as string
      body["speech_models"] = [model]
    }
  }

  // Ensure speech_models is always set (AssemblyAI requires it)
  if (!body["speech_models"]) {
    body["speech_models"] = ["universal-3-pro"]
  }

  // Diarization speaker count
  if (options?.["diarization_config.min_speakers"] !== undefined) {
    body["speakers_expected"] = options["diarization_config.min_speakers"]
  }

  const response = await fetch("https://api.assemblyai.com/v2/transcript", {
    method: "POST",
    headers: {
      "Authorization": apiKeyConfig.apiKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => "unknown error")
    logger.error({ provider: "assemblyai", status: response.status, error: errorText }, "AssemblyAI submission failed")
    throw new Error(`AssemblyAI submission failed (${response.status}): ${errorText}`)
  }

  const result = await response.json() as { id: string; status: string }
  logger.info({ provider: "assemblyai", jobId: result.id, status: result.status }, "AssemblyAI transcription job submitted")
  return { providerJobId: result.id }
}

// ─── Deepgram ───────────────────────────────────────────────────────

async function submitToDeepgram(
  audioUrl: string,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options: BatchTranscriptionOptions | undefined,
  logger: Logger
): Promise<SubmitBatchResult> {
  const params = new URLSearchParams()
  params.set("callback", webhookUrl)

  // Always request diarization so Deepgram returns utterance-level data
  if (options?.diarization !== false) params.set("diarize", "true")
  if (options?.language) params.set("language", options.language)
  if (options?.model) params.set("model", options.model)

  // Diarization speaker count
  if (options?.["diarization_config.min_speakers"] !== undefined) {
    // Deepgram doesn't have min_speakers but has a general diarize param
  }

  // Apply custom params as query params (Deepgram uses query params for options)
  if (options) {
    for (const [key, value] of Object.entries(options)) {
      if (!["diarization", "language", "summarization", "model", "diarization_config.min_speakers", "callback"].includes(key)) {
        if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
          params.set(key, String(value))
        }
      }
    }
  }

  const response = await fetch(`https://api.deepgram.com/v1/listen?${params.toString()}`, {
    method: "POST",
    headers: {
      "Authorization": `Token ${apiKeyConfig.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ url: audioUrl })
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => "unknown error")
    logger.error({ provider: "deepgram", status: response.status, error: errorText }, "Deepgram submission failed")
    throw new Error(`Deepgram submission failed (${response.status}): ${errorText}`)
  }

  const result = await response.json() as { request_id: string }
  logger.info({ provider: "deepgram", jobId: result.request_id }, "Deepgram transcription job submitted")
  return { providerJobId: result.request_id }
}

// ─── Speechmatics ──────────────────────────────────────────────────

async function submitToSpeechmatics(
  audioUrl: string,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options: BatchTranscriptionOptions | undefined,
  logger: Logger
): Promise<SubmitBatchResult> {
  // Always use EU endpoint — region is not user-configurable
  const baseUrl = "https://asr.api.speechmatics.com"

  const transcriptionConfig: Record<string, unknown> = {
    language: options?.language ?? "en"
  }

  // Always request diarization so Speechmatics returns utterance-level data
  if (options?.diarization !== false) {
    transcriptionConfig["diarization"] = "speaker"
  }

  const config: Record<string, unknown> = {
    type: "transcription",
    transcription_config: transcriptionConfig,
    notification_config: [
      {
        url: webhookUrl,
        contents: ["transcript"]
      }
    ],
    fetch_data: {
      url: audioUrl
    }
  }

  // Apply custom params
  if (options) {
    for (const [key, value] of Object.entries(options)) {
      if (!["diarization", "language", "summarization", "model", "diarization_config.min_speakers", "notification_config", "fetch_data"].includes(key)) {
        if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
          transcriptionConfig[key] = value
        }
      }
    }
  }

  // Speechmatics batch API uses multipart/form-data with a config JSON field
  const formData = new FormData()
  formData.append("config", JSON.stringify(config))

  const response = await fetch(`${baseUrl}/v2/jobs`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKeyConfig.apiKey}`
    },
    body: formData
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => "unknown error")
    logger.error({ provider: "speechmatics", status: response.status, error: errorText }, "Speechmatics submission failed")
    throw new Error(`Speechmatics submission failed (${response.status}): ${errorText}`)
  }

  const result = await response.json() as { id: string }
  logger.info({ provider: "speechmatics", jobId: result.id }, "Speechmatics transcription job submitted")
  return { providerJobId: result.id }
}

// ─── Soniox ─────────────────────────────────────────────────────────

async function submitToSoniox(
  audioUrl: string,
  apiKeyConfig: ApiKeyConfig,
  webhookUrl: string,
  options: BatchTranscriptionOptions | undefined,
  logger: Logger
): Promise<SubmitBatchResult> {
  const body: Record<string, unknown> = {
    model: options?.model ?? "stt-async-preview",
    audio_url: audioUrl,
    webhook_url: webhookUrl,
    enable_speaker_diarization: options?.diarization !== false
  }

  if (options?.language) {
    body["language_hints"] = [options.language]
  }

  // Pass through custom params (never allow webhook URL override)
  if (options) {
    const unflattened = unflattenKeys(options)
    for (const [key, value] of Object.entries(unflattened)) {
      if (!["diarization", "language", "summarization", "model", "webhook_url", "audio_url"].includes(key)) {
        body[key] = value
      }
    }
  }

  const response = await fetch("https://api.soniox.com/v1/transcriptions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKeyConfig.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  })

  if (!response.ok) {
    const errorText = await response.text().catch(() => "unknown error")
    logger.error({ provider: "soniox", status: response.status, error: errorText }, "Soniox submission failed")
    throw new Error(`Soniox submission failed (${response.status}): ${errorText}`)
  }

  const result = await response.json() as { id: string; status: string }
  logger.info({ provider: "soniox", jobId: result.id, status: result.status }, "Soniox transcription job submitted")
  return { providerJobId: result.id }
}
