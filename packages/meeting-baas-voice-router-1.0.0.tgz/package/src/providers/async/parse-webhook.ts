import type { BatchTranscriptionResult, BatchTranscriptionSuccess, BatchUtterance } from "@/types/async"
import type { BatchApiKeyConfig, TranscriptWord } from "@/types/common"
import { createAdapter } from "@/providers/adapter"

/**
 * Minimal interface for the SDK's webhook/transcript data shape.
 * Used for both UnifiedWebhookEvent.data and UnifiedTranscriptResponse.data
 * (avoids importing the full SDK type to keep builds fast).
 */
interface SdkTranscriptData {
  id: string
  status: string
  text?: string
  confidence?: number
  duration?: number
  language?: string
  speakers?: Array<{ id: string; label?: string }>
  words?: Array<{ word: string; start: number; end: number; confidence?: number; speaker?: string }>
  utterances?: Array<{
    text: string
    start: number
    end: number
    speaker?: string
    confidence?: number
    words?: Array<{ word: string; start: number; end: number; confidence?: number; speaker?: string }>
  }>
  summary?: string
  error?: string
  metadata?: Record<string, unknown>
}

interface SdkWebhookEvent {
  success: boolean
  provider: string
  eventType: string
  data?: SdkTranscriptData
  raw: unknown
}

interface SdkWebhookRouterResult {
  success: boolean
  provider?: string
  event?: SdkWebhookEvent
  error?: string
}

interface SdkWebhookRouterInstance {
  route(payload: unknown, options?: {
    provider?: string
    queryParams?: Record<string, string>
    userAgent?: string
  }): SdkWebhookRouterResult
}

interface SdkTranscriptResponse {
  success: boolean
  data?: SdkTranscriptData
  tracking?: { processingTimeMs?: number }
  error?: { code?: string; message?: string }
  raw?: unknown
}

interface SdkWebhookExports {
  WebhookRouter: new () => SdkWebhookRouterInstance
}

let sdkWebhookImport: Promise<SdkWebhookExports> | null = null

function getSdkWebhooks(): Promise<SdkWebhookExports> {
  if (!sdkWebhookImport) {
    sdkWebhookImport = import("voice-router-dev/webhooks" as never) as unknown as Promise<SdkWebhookExports>
  }
  return sdkWebhookImport
}

/**
 * Parse a webhook callback payload from any supported provider.
 *
 * Uses the voice-router-dev SDK's WebhookRouter for all providers.
 * If the webhook contains full transcript data (Gladia, Deepgram, AssemblyAI,
 * Speechmatics), it's used directly. If the webhook is notification-only
 * (Soniox), falls back to adapter.getTranscript() to fetch the full transcript.
 *
 * Returns a BatchTranscriptionResult so callers can reuse the same
 * downstream processing pipeline.
 */
export async function parseWebhookCallback(
  provider: string,
  body: unknown,
  queryParams?: Record<string, string> | undefined,
  apiKeyConfig?: BatchApiKeyConfig | undefined
): Promise<BatchTranscriptionResult> {
  // 1. Parse webhook via SDK WebhookRouter
  const { WebhookRouter } = await getSdkWebhooks()
  const router = new WebhookRouter()
  const routeResult = router.route(body, {
    provider,
    ...(queryParams ? { queryParams } : {})
  })

  if (!routeResult.success || !routeResult.event) {
    return {
      success: false,
      error: { code: "WEBHOOK_PARSE_FAILED", message: routeResult.error ?? `Failed to parse ${provider} webhook` }
    }
  }

  const event = routeResult.event

  // 2. Handle failure events
  if (!event.success || event.eventType === "transcription.failed") {
    return {
      success: false,
      error: {
        code: "TRANSCRIPTION_FAILED",
        message: event.data?.error ?? "Provider transcription failed"
      }
    }
  }

  // 3. If webhook contains full transcript data, use it directly
  if (event.data && hasTranscriptContent(event.data)) {
    return convertSdkDataToResult(event.data, {
      raw: event.raw ?? body,
      processingTimeMs: 0
    })
  }

  // 4. Webhook is notification-only — fetch full transcript via adapter
  const jobId = event.data?.id
  if (!jobId) {
    return {
      success: false,
      error: { code: "MISSING_JOB_ID", message: "Webhook missing job ID and no transcript data" }
    }
  }

  if (!apiKeyConfig) {
    return {
      success: false,
      error: { code: "MISSING_API_KEY", message: `${provider} requires API key to fetch transcript` }
    }
  }

  return fetchTranscriptViaAdapter(provider, jobId, apiKeyConfig, body)
}

// ─── Helpers ─────────────────────────────────────────────────────────

/**
 * Check if webhook data contains actual transcript content
 * (not just a notification with id + status).
 */
function hasTranscriptContent(data: SdkTranscriptData): boolean {
  return (data.text !== undefined && data.text !== "") ||
    (data.utterances !== undefined && data.utterances.length > 0) ||
    (data.words !== undefined && data.words.length > 0)
}

/**
 * Fetch full transcript via SDK adapter when webhook is notification-only.
 */
async function fetchTranscriptViaAdapter(
  provider: string,
  jobId: string,
  apiKeyConfig: BatchApiKeyConfig,
  webhookBody: unknown
): Promise<BatchTranscriptionResult> {
  const adapter = createAdapter(apiKeyConfig)
  if (!adapter) {
    return {
      success: false,
      error: { code: "ADAPTER_INIT_FAILED", message: `Failed to create ${provider} adapter` }
    }
  }

  try {
    const response = await adapter.getTranscript(jobId) as unknown as SdkTranscriptResponse

    if (!response.success || !response.data) {
      return {
        success: false,
        error: {
          code: response.error?.code ?? "TRANSCRIPT_FETCH_FAILED",
          message: response.error?.message ?? `Failed to fetch ${provider} transcript`
        }
      }
    }

    return convertSdkDataToResult(response.data, {
      raw: { webhook: webhookBody, transcript: response.raw },
      processingTimeMs: response.tracking?.processingTimeMs ?? 0
    })
  } catch (error) {
    return {
      success: false,
      error: {
        code: "TRANSCRIPT_FETCH_FAILED",
        message: `Failed to fetch ${provider} transcript: ${error instanceof Error ? error.message : String(error)}`
      }
    }
  }
}

/**
 * Convert SDK transcript data (from webhook event or getTranscript response)
 * to our BatchTranscriptionSuccess format.
 */
function convertSdkDataToResult(
  data: SdkTranscriptData,
  opts: { raw: unknown; processingTimeMs: number }
): BatchTranscriptionSuccess {
  // Convert SDK words → TranscriptWord
  const words: TranscriptWord[] | undefined = data.words?.map((w) => {
    const tw: TranscriptWord = { text: w.word, start: w.start, end: w.end }
    if (w.confidence !== undefined) tw.confidence = w.confidence
    return tw
  })

  // Convert SDK utterances → BatchUtterance
  const utterances: BatchUtterance[] | undefined = data.utterances?.map((u) => {
    const bu: BatchUtterance = {
      text: u.text,
      start: u.start,
      end: u.end,
      words: (u.words ?? []).map((w) => {
        const tw: TranscriptWord = { text: w.word, start: w.start, end: w.end }
        if (w.confidence !== undefined) tw.confidence = w.confidence
        return tw
      })
    }
    if (u.confidence !== undefined) bu.confidence = u.confidence
    if (u.speaker !== undefined) bu.speaker = u.speaker
    return bu
  })

  const result: BatchTranscriptionSuccess = {
    success: true,
    text: data.text ?? "",
    processingTimeMs: opts.processingTimeMs,
    rawProviderResponse: opts.raw
  }

  if (words !== undefined) result.words = words
  if (utterances !== undefined) result.utterances = utterances
  if (data.language !== undefined) result.language = data.language
  if (data.duration !== undefined) result.audioDuration = data.duration
  if (data.id !== undefined) result.providerJobId = data.id
  if (data.summary !== undefined) result.summary = data.summary
  if (data.speakers !== undefined) {
    result.speakers = data.speakers.map((s) => ({
      id: s.id,
      name: s.label
    }))
  }

  return result
}
