import { randomUUID } from "crypto"
import type { BatchTranscriptionOptions, BatchTranscriptionResult } from "@/types/async"

interface StubJob {
  createdAtMs: number
}

const QUEUED_DURATION_MS = 1000
const PROCESSING_DURATION_MS = 3000

const jobs = new Map<string, StubJob>()

/**
 * Stub batch transcription for testing without API keys.
 * Returns fake results that transition from processing to done over ~4s.
 */
export async function transcribeBatchStub(
  _url: string,
  _options?: BatchTranscriptionOptions
): Promise<BatchTranscriptionResult> {
  const jobId = randomUUID()
  jobs.set(jobId, { createdAtMs: Date.now() })

  // Simulate processing delay
  const totalDelay = QUEUED_DURATION_MS + PROCESSING_DURATION_MS
  await new Promise((resolve) => setTimeout(resolve, totalDelay))

  jobs.delete(jobId)

  return {
    success: true,
    text: "This is a stub transcription result for testing purposes.",
    words: [
      { text: "This", start: 0, end: 0.3, confidence: 0.95 },
      { text: "is", start: 0.3, end: 0.5, confidence: 0.97 },
      { text: "a", start: 0.5, end: 0.6, confidence: 0.99 },
      { text: "stub", start: 0.6, end: 1.0, confidence: 0.95 },
      { text: "transcription", start: 1.0, end: 1.8, confidence: 0.93 },
      { text: "result", start: 1.8, end: 2.3, confidence: 0.94 }
    ],
    language: "en",
    processingTimeMs: totalDelay,
    providerJobId: jobId
  }
}
