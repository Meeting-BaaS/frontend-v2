import type {
  StreamingSession as SdkStreamingSession,
  StreamingCallbacks as SdkStreamingCallbacks
} from "voice-router-dev"
import type { StreamingProvider, ApiKeyConfig, TranscriptWord, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type {
  StreamingSession,
  StreamingCallbacks,
  StreamingConfig,
  ProviderStreamingOptions
} from "@/types/streaming"
import { createAdapter } from "@/providers/adapter"
import { buildStreamingOptions } from "./options"

/**
 * Start a streaming transcription session using the voice-router-dev SDK.
 * Returns a StreamingSession or null if the provider is not supported/configured.
 */
export async function startStreamingSession(
  provider: StreamingProvider,
  config: StreamingConfig,
  callbacks: StreamingCallbacks,
  providerOptions?: ProviderStreamingOptions,
  apiKeyConfig?: ApiKeyConfig,
  logger?: Logger | undefined
): Promise<StreamingSession | null> {
  const log = logger ?? defaultLogger

  if (!apiKeyConfig?.apiKey) {
    log.error({ provider }, "Cannot start streaming: no API key")
    return null
  }

  const adapter = createAdapter(provider, { apiKey: apiKeyConfig.apiKey })
  if (!adapter) {
    log.error({ provider }, "Unsupported streaming provider")
    return null
  }

  const options = buildStreamingOptions(provider, config, providerOptions)

  try {
    const sdkCallbacks: SdkStreamingCallbacks = {
      onOpen: () => {
        callbacks.onOpen?.()
      },
      onTranscript: (event) => {
        const text = event.text ?? ""
        const isFinal = event.isFinal ?? false

        let utteranceStart: number | undefined
        let utteranceEnd: number | undefined
        let confidence: number | undefined

        if (event.utterance) {
          utteranceStart = event.utterance.start
          utteranceEnd = event.utterance.end
          confidence = event.utterance.confidence
        } else if (event.words && event.words.length > 0) {
          const firstWord = event.words[0]
          const lastWord = event.words[event.words.length - 1]
          utteranceStart = firstWord?.start
          utteranceEnd = lastWord?.end
        }

        // Fall back to start + duration for interim results (Deepgram format)
        const rawEvent = event as unknown as Record<string, unknown>
        if (utteranceStart === undefined && typeof rawEvent["start"] === "number") {
          utteranceStart = rawEvent["start"] as number
        }
        if (
          utteranceEnd === undefined &&
          typeof rawEvent["start"] === "number" &&
          typeof rawEvent["duration"] === "number"
        ) {
          utteranceEnd = (rawEvent["start"] as number) + (rawEvent["duration"] as number)
        }

        if (event.confidence !== undefined) {
          confidence = event.confidence
        }

        const words: TranscriptWord[] | undefined = event.words?.map((w) => {
          const word: TranscriptWord = {
            text: w.word,
            start: w.start,
            end: w.end
          }
          if (w.confidence !== undefined) word.confidence = w.confidence
          if (w.speaker !== undefined) word.speaker = w.speaker
          return word
        })

        callbacks.onTranscript({
          text,
          isFinal,
          utteranceStart,
          utteranceEnd,
          confidence,
          words
        })
      },
      onUtterance: () => {
        // Intentionally empty — final transcripts come via onTranscript with isFinal=true
      },
      onMetadata: (metadata) => {
        const meta = metadata as unknown as Record<string, unknown>
        const requestId = (meta["request_id"] ?? meta["id"] ?? meta["session_id"]) as string | undefined
        if (requestId) {
          callbacks.onMetadata?.({ requestId, ...metadata })
        } else {
          callbacks.onMetadata?.({ ...metadata } as Record<string, unknown> & { requestId?: string })
        }
      },
      onRawMessage: (message) => {
        callbacks.onRawMessage?.(message)
      },
      onError: (error) => {
        callbacks.onError(new Error(error.message))
      },
      onClose: (code, reason) => {
        callbacks.onClose?.(code ?? 1000, reason ?? "Normal closure")
      }
    }

    // Use adapter's transcribeStream method
    const adapterAny = adapter as unknown as { transcribeStream?: (opts: unknown, cbs: unknown) => Promise<SdkStreamingSession> }
    if (!adapterAny.transcribeStream) {
      log.error({ provider }, "Adapter does not support streaming")
      return null
    }
    const session: SdkStreamingSession = await adapterAny.transcribeStream(options, sdkCallbacks)

    return {
      sendAudio: async (chunk: { data: Buffer }) => {
        await session.sendAudio({ data: chunk.data })
      },
      endAudio: async () => {
        await session.sendAudio({ data: Buffer.alloc(0), isLast: true })
      },
      close: async () => {
        await session.close()
      }
    }
  } catch (e) {
    log.error(
      { provider, error: e instanceof Error ? e.message : String(e) },
      "Failed to start streaming session"
    )
    return null
  }
}
