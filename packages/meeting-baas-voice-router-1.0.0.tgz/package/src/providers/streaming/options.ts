import type { StreamingProvider } from "@/types/common"
import type { StreamingConfig, ProviderStreamingOptions } from "@/types/streaming"

/**
 * Unflatten dot-notation keys into nested objects.
 * e.g., { "language_config.languages": ["fr"] } -> { language_config: { languages: ["fr"] } }
 */
export function unflattenKeys(obj: Record<string, unknown>): Record<string, unknown> {
  const result: Record<string, unknown> = {}

  for (const [key, value] of Object.entries(obj)) {
    if (!key.includes(".")) {
      result[key] = value
      continue
    }

    const parts = key.split(".")
    let current: Record<string, unknown> = result
    for (let i = 0; i < parts.length - 1; i += 1) {
      const part = parts[i]
      if (!part) continue
      const next = current[part]
      if (!next || typeof next !== "object") {
        current[part] = {}
      }
      current = current[part] as Record<string, unknown>
    }

    const last = parts[parts.length - 1]
    if (last) current[last] = value
  }

  return result
}

const ENCODING_TO_GLADIA: Record<string, string> = {
  linear16: "wav/pcm",
  pcm_s16le: "wav/pcm",
  mulaw: "wav/ulaw",
  alaw: "wav/alaw"
}

export function toGladiaEncoding(encoding: string): string {
  return ENCODING_TO_GLADIA[encoding] ?? encoding
}

/**
 * Build streaming options for the voice-router-dev SDK.
 * Returns a provider-specific options object.
 *
 * @param region - Regional endpoint from the typed API key config. For Gladia
 *   (SDK >=0.9.4), this is set as a top-level `region` field in the options
 *   (per `GladiaStreamingOptions.region`), separate from the `gladiaStreaming`
 *   request-body object. The adapter also receives region at init time as a
 *   fallback, but per-call takes precedence.
 */
export function buildStreamingOptions(
  provider: StreamingProvider,
  config: StreamingConfig,
  providerOptions?: ProviderStreamingOptions,
  region?: string
): Record<string, unknown> {
  const base = {
    encoding: config.encoding,
    sampleRate: config.sampleRate,
    channels: config.channels,
    interimResults: config.interimResults ?? true
  }

  switch (provider) {
    case "deepgram":
      return {
        ...base,
        deepgramStreaming: {
          language: config.language,
          interimResults: config.interimResults ?? true,
          ...unflattenKeys((providerOptions?.deepgram as Record<string, unknown>) ?? {})
        }
      }
    case "gladia":
      return {
        ...base,
        ...(region ? { region } : {}),
        gladiaStreaming: unflattenKeys(
          (providerOptions?.gladia as Record<string, unknown>) ?? {}
        )
      }
    case "assemblyai":
      return {
        ...base,
        assemblyaiStreaming: unflattenKeys(
          (providerOptions?.assemblyai as Record<string, unknown>) ?? {}
        )
      }
    case "speechmatics":
      return {
        ...base,
        speechmaticsStreaming: {
          language: config.language,
          ...unflattenKeys((providerOptions?.speechmatics as Record<string, unknown>) ?? {})
        }
      }
    case "soniox":
      return {
        ...base,
        sonioxStreaming: unflattenKeys(
          (providerOptions?.soniox as Record<string, unknown>) ?? {}
        )
      }
    case "elevenlabs":
      return {
        ...base,
        elevenlabsStreaming: unflattenKeys(
          (providerOptions?.elevenlabs as Record<string, unknown>) ?? {}
        )
      }
    default:
      return base
  }
}
