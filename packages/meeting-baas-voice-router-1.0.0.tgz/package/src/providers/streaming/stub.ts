import type { TranscriptWord, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type { StreamingSession, StreamingCallbacks, StreamingConfig } from "@/types/streaming"

const STUB_TRANSCRIPT_INTERVAL_MS = 5000

/**
 * Start a stub streaming session for testing without API keys.
 * Emits fake transcripts every 5s and logs audio stats.
 */
export function startStubStreamingSession(
  _config: StreamingConfig,
  callbacks: StreamingCallbacks,
  logger?: Logger | undefined
): StreamingSession {
  const log = logger ?? defaultLogger
  let connected = true
  let bytesReceived = 0
  let chunkCount = 0
  let segmentIndex = 0

  const interval = setInterval(() => {
    if (!connected) return

    const words: TranscriptWord[] = [
      { text: "stub", start: segmentIndex * 5, end: segmentIndex * 5 + 2.5, confidence: 0.95 },
      { text: "transcript", start: segmentIndex * 5 + 2.5, end: (segmentIndex + 1) * 5, confidence: 0.95 }
    ]

    callbacks.onTranscript({
      text: `[stub transcript segment ${segmentIndex}]`,
      isFinal: true,
      utteranceStart: segmentIndex * 5,
      utteranceEnd: (segmentIndex + 1) * 5,
      confidence: 0.95,
      words
    })
    segmentIndex++
  }, STUB_TRANSCRIPT_INTERVAL_MS)

  callbacks.onOpen?.()

  return {
    sendAudio: async (chunk: { data: Buffer }) => {
      if (!connected) return
      bytesReceived += chunk.data.length
      chunkCount++
      if (chunkCount % 100 === 0) {
        log.info({ chunkCount, bytesReceived }, "Stub streaming audio stats")
      }
    },
    endAudio: async () => {
      log.info({ chunkCount, bytesReceived }, "Stub streaming endAudio")
    },
    close: async () => {
      connected = false
      clearInterval(interval)
      callbacks.onClose?.(1000, "Normal closure")
      log.info({ chunkCount, bytesReceived }, "Stub streaming closed")
    }
  }
}
