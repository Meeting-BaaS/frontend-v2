import type { StreamingProvider, Provider, ApiKeyConfig, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type {
  StreamingSession,
  StreamingCallbacks,
  StreamingConfig,
  ProviderStreamingOptions
} from "@/types/streaming"
import type { BatchTranscriptionOptions, BatchTranscriptionResult } from "@/types/async"
import { startStreamingSession } from "./streaming/base"
import { startStubStreamingSession } from "./streaming/stub"
import { transcribeBatch } from "./async/base"
import { transcribeBatchStub } from "./async/stub"

/**
 * Start a streaming transcription session.
 * Falls back to stub provider if no API key is configured.
 */
export async function createStreamingSession(
  provider: StreamingProvider,
  config: StreamingConfig,
  callbacks: StreamingCallbacks,
  providerOptions?: ProviderStreamingOptions,
  apiKeyConfig?: ApiKeyConfig,
  logger?: Logger | undefined
): Promise<StreamingSession | null> {
  const log = logger ?? defaultLogger

  if (!apiKeyConfig?.apiKey) {
    log.warn(
      { provider },
      "No API key for streaming provider, using stub"
    )
    return startStubStreamingSession(config, callbacks, log)
  }

  return startStreamingSession(provider, config, callbacks, providerOptions, apiKeyConfig, log)
}

/**
 * Run batch transcription on an audio URL.
 * Falls back to stub provider if no API key is configured.
 */
export async function runBatchTranscription(
  url: string,
  provider: Provider,
  apiKeyConfig?: ApiKeyConfig,
  options?: BatchTranscriptionOptions,
  logger?: Logger | undefined
): Promise<BatchTranscriptionResult> {
  const log = logger ?? defaultLogger

  if (!apiKeyConfig?.apiKey) {
    log.warn(
      { provider },
      "No API key for batch provider, using stub"
    )
    return transcribeBatchStub(url, options)
  }

  return transcribeBatch(url, provider, apiKeyConfig, options, log)
}
