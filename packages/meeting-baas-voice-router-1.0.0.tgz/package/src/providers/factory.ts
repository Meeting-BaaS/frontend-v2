import type { StreamingProvider, StreamingApiKeyConfig, Logger } from "@/types/common"
import { defaultLogger } from "@/types/common"
import type {
  StreamingSession,
  StreamingCallbacks,
  StreamingConfig,
  ProviderStreamingOptions
} from "@/types/streaming"
import { startStreamingSession } from "./streaming/base"
import { startStubStreamingSession } from "./streaming/stub"

/**
 * Start a streaming transcription session.
 * Falls back to stub provider if no API key is configured.
 */
export async function createStreamingSession(
  provider: StreamingProvider,
  config: StreamingConfig,
  callbacks: StreamingCallbacks,
  providerOptions?: ProviderStreamingOptions,
  apiKeyConfig?: StreamingApiKeyConfig,
  logger?: Logger | undefined
): Promise<StreamingSession | null> {
  const log = logger ?? defaultLogger

  if (!apiKeyConfig?.apiKey) {
    log.warn(
      { provider },
      "No API key for streaming provider, using stub"
    )
    return startStubStreamingSession(config, callbacks, log)
  }

  return startStreamingSession(provider, config, callbacks, providerOptions, apiKeyConfig, log)
}
