import {
  createGladiaAdapter,
  createDeepgramAdapter,
  createAssemblyAIAdapter,
  createSpeechmaticsAdapter,
  createSonioxAdapter,
  createElevenLabsAdapter
} from "voice-router-dev"
import type { TranscriptionAdapter } from "voice-router-dev"
import type { BatchApiKeyConfig, StreamingApiKeyConfig } from "@/types/common"

export type AdapterType = TranscriptionAdapter

/**
 * Create a provider adapter for transcript management (get, delete, list).
 *
 * Accepts a provider-discriminated config — the provider field determines
 * which adapter factory is called and region is already the correct SDK type.
 */
export function createAdapter(
  config: BatchApiKeyConfig | StreamingApiKeyConfig
): AdapterType | null {
  switch (config.provider) {
    case "gladia": {
      if ("region" in config) {
        return createGladiaAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
      }
      return createGladiaAdapter({ apiKey: config.apiKey }) as AdapterType
    }
    case "deepgram":
      return createDeepgramAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
    case "assemblyai":
      return createAssemblyAIAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
    case "speechmatics":
      return createSpeechmaticsAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
    case "soniox":
      return createSonioxAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
    case "elevenlabs":
      return createElevenLabsAdapter({ apiKey: config.apiKey, region: config.region }) as AdapterType
    default:
      return null
  }
}
