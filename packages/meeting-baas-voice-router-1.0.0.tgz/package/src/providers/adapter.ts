import {
  createGladiaAdapter,
  createDeepgramAdapter,
  createAssemblyAIAdapter,
  createSpeechmaticsAdapter,
  createSonioxAdapter,
  createElevenLabsAdapter
} from "voice-router-dev"
import type { TranscriptionAdapter } from "voice-router-dev"
import type { Provider, ApiKeyConfig } from "@/types/common"

export type AdapterType = TranscriptionAdapter

// EU regions hardcoded — not user-configurable
export function createAdapter(
  provider: Provider,
  config: ApiKeyConfig
): AdapterType | null {
  const { apiKey } = config

  switch (provider) {
    case "gladia":
      return createGladiaAdapter({ apiKey }) as AdapterType
    case "deepgram":
      return createDeepgramAdapter({ apiKey, region: "eu" as never }) as AdapterType
    case "assemblyai":
      return createAssemblyAIAdapter({ apiKey }) as AdapterType
    case "speechmatics":
      return createSpeechmaticsAdapter({ apiKey, region: "eu1" as never }) as AdapterType
    case "soniox":
      return createSonioxAdapter({ apiKey, region: "eu" as never }) as AdapterType
    case "elevenlabs":
      return createElevenLabsAdapter({ apiKey }) as AdapterType
    default:
      return null
  }
}
