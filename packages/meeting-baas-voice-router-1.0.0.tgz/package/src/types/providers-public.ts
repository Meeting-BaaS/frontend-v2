/**
 * Frontend-safe provider constants — zero SDK imports.
 *
 * This module is the single source of truth for provider names, display names,
 * and region string arrays that can be safely bundled by frontend build tools
 * (Next.js, Vite, etc.) without pulling in the voice-router-dev SDK.
 *
 * Region string arrays intentionally duplicate values from the SDK enums.
 * A drift-detection test asserts they stay in sync at CI time.
 * @see tests/providers-public.test.ts
 */

// ─── Provider lists ──────────────────────────────────────────────────

/** Providers that support post-meeting batch transcription. */
export const BATCH_PROVIDERS = [
  "gladia",
  "deepgram",
  "assemblyai",
  "speechmatics",
  "soniox"
] as const

export type BatchProvider = (typeof BATCH_PROVIDERS)[number]

/** Providers that support real-time streaming (batch providers + streaming-only). */
export const STREAMING_PROVIDERS = [
  ...BATCH_PROVIDERS,
  "elevenlabs"
] as const

export type StreamingProvider = (typeof STREAMING_PROVIDERS)[number]

/** All supported transcription providers (batch + streaming). */
export const PROVIDERS = STREAMING_PROVIDERS

export type Provider = StreamingProvider

// ─── Display names ───────────────────────────────────────────────────

/** Human-readable display names for each provider. */
export const PROVIDER_DISPLAY_NAMES: Record<Provider, string> = {
  gladia: "Gladia",
  deepgram: "Deepgram",
  assemblyai: "AssemblyAI",
  speechmatics: "Speechmatics",
  soniox: "Soniox",
  elevenlabs: "ElevenLabs"
}

// ─── Region lists (hardcoded mirrors of SDK enums) ───────────────────

/**
 * Allowed regions per provider for batch transcription.
 * Gladia has no batch region — batch always uses the global `api.gladia.io` endpoint.
 *
 * Values must match `Object.values(SdkRegionEnum)` for each provider.
 */
export const BATCH_PROVIDER_REGIONS = {
  deepgram: ["global", "eu"] as const,
  assemblyai: ["us", "eu"] as const,
  speechmatics: ["eu1", "eu2", "us1", "us2", "au1"] as const,
  soniox: ["us", "eu", "jp"] as const
} as const satisfies Partial<Record<BatchProvider, readonly string[]>>

/**
 * Allowed regions per provider for streaming transcription.
 * All six streaming providers have region support.
 *
 * Values must match `Object.values(SdkRegionEnum)` for each provider.
 */
export const STREAMING_PROVIDER_REGIONS = {
  gladia: ["us-west", "eu-west"] as const,
  deepgram: ["global", "eu"] as const,
  assemblyai: ["us", "eu"] as const,
  speechmatics: ["eu1", "eu2", "us1", "us2", "au1"] as const,
  soniox: ["us", "eu", "jp"] as const,
  elevenlabs: ["global", "us", "eu", "in"] as const
} as const satisfies Record<StreamingProvider, readonly string[]>
