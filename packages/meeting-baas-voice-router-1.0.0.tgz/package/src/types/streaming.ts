import type { StreamingProvider, TranscriptWord } from "./common"
import type { RawWebSocketMessage } from "voice-router-dev"

/**
 * Audio encoding formats for streaming
 */
export type AudioEncoding = "linear16" | "pcm_s16le" | "opus" | "mulaw" | "flac"

/**
 * Streaming session configuration
 */
export interface StreamingConfig {
  encoding: AudioEncoding
  sampleRate: number
  channels: 1 | 2
  language?: string | undefined
  interimResults?: boolean | undefined
}

/**
 * A live streaming session returned by startStreamingSession()
 */
export interface StreamingSession {
  sendAudio: (chunk: { data: Buffer }) => Promise<void>
  /**
   * Signal that all audio has been sent. Tells the provider to flush remaining
   * transcripts (e.g. stop_recording for Gladia, CloseStream for Deepgram)
   * WITHOUT closing the WebSocket, so final transcripts can still arrive.
   */
  endAudio: () => Promise<void>
  close: () => Promise<void>
}

/**
 * Provider-specific metadata from streaming sessions
 */
export interface ProviderMetadata {
  requestId?: string | undefined
  [key: string]: unknown
}

/**
 * Callbacks for streaming session events
 */
export interface StreamingCallbacks {
  onOpen?: () => void
  onTranscript: (event: {
    text?: string | undefined
    isFinal?: boolean | undefined
    utteranceStart?: number | undefined
    utteranceEnd?: number | undefined
    confidence?: number | undefined
    words?: TranscriptWord[] | undefined
  }) => void
  onMetadata?: (metadata: ProviderMetadata) => void
  onError: (error: Error) => void
  onClose?: (code: number, reason: string) => void
  onRawMessage?: (message: RawWebSocketMessage) => void
}

// ==================== Per-Provider Streaming Options ====================

export interface DeepgramStreamingOptions {
  model?: string
  language?: string
  punctuate?: boolean
  profanityFilter?: boolean
  diarize?: boolean
  smartFormat?: boolean
  interimResults?: boolean
  endpointing?: number | false
  utteranceEndMs?: number
  encoding?: string
  sampleRate?: number
  channels?: number
}

export interface GladiaStreamingOptions {
  language?: string
  languageBehaviour?: "manual" | "automatic single language" | "automatic multiple languages"
  transcriptionHint?: string
  endpointing?: number
  prosody?: boolean
  modelType?: "fast" | "accurate"
  encoding?: string
  sampleRate?: number
}

export interface AssemblyAIStreamingOptions {
  speechModel?: string
  sampleRate?: number
  wordBoost?: string[]
  filterProfanity?: boolean
  redactPii?: boolean
  languageDetection?: boolean
  vadThreshold?: number
  endOfTurnConfidenceThreshold?: number
}

export interface SpeechmaticsStreamingOptions {
  language?: string
  enablePartials?: boolean
  speakerDiarization?: boolean
  maxDelay?: number
  maxDelayMode?: "flexible" | "fixed"
  operatingPoint?: "standard" | "enhanced"
}

export interface SonioxStreamingOptions {
  model?: string
  language?: string
  enableDictation?: boolean
  enableProfanityFilter?: boolean
  enableSpeakerDiarization?: boolean
  numSpeakers?: number
}

export interface ElevenLabsStreamingOptions {
  model?: string
  language?: string
}

/**
 * Provider-specific streaming options map
 */
export interface ProviderStreamingOptions {
  gladia?: GladiaStreamingOptions
  deepgram?: DeepgramStreamingOptions
  assemblyai?: AssemblyAIStreamingOptions
  speechmatics?: SpeechmaticsStreamingOptions
  soniox?: SonioxStreamingOptions
  elevenlabs?: ElevenLabsStreamingOptions
}

// ==================== Bot Protocol Types ====================

export interface HandshakeMessage {
  protocol_version: number
  bot_id: string
  offset: number
  sample_rate: number
}

export interface SpeakerData {
  name: string
  id: number
  timestamp: number
  isSpeaking: boolean
}

// ==================== Provider Audio Config ====================

export interface ProviderAudioConfig {
  sampleRate: number
  encoding: AudioEncoding
  bitDepth: number
  channels: number
  supportsNativeRate: boolean
  maxSampleRate: number
}

export const PROVIDER_AUDIO_CONFIG: Record<StreamingProvider, ProviderAudioConfig> = {
  deepgram: {
    sampleRate: 48000,
    encoding: "linear16",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: true,
    maxSampleRate: 48000
  },
  assemblyai: {
    sampleRate: 16000,
    encoding: "linear16",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: false,
    maxSampleRate: 16000
  },
  gladia: {
    sampleRate: 16000,
    encoding: "linear16",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: false,
    maxSampleRate: 48000
  },
  speechmatics: {
    sampleRate: 16000,
    encoding: "pcm_s16le",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: true,
    maxSampleRate: 48000
  },
  soniox: {
    sampleRate: 16000,
    encoding: "pcm_s16le",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: true,
    maxSampleRate: 48000
  },
  elevenlabs: {
    sampleRate: 16000,
    encoding: "linear16",
    bitDepth: 16,
    channels: 1,
    supportsNativeRate: false,
    maxSampleRate: 16000
  }
}
