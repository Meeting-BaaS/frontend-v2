import type { TranscriptWord } from "./common"

/**
 * Options for batch transcription
 */
export interface BatchTranscriptionOptions {
  language?: string | undefined
  diarization?: boolean | undefined
  summarization?: boolean | undefined
  model?: string | undefined
  [key: string]: unknown
}

/**
 * Utterance-level data from batch transcription (needed for speaker mapping)
 */
export interface BatchUtterance {
  text: string
  start: number
  end: number
  confidence?: number | undefined
  channel?: number | undefined
  speaker?: number | string | undefined
  language?: string | undefined
  words: TranscriptWord[]
}

/**
 * Successful batch transcription result
 */
export interface BatchTranscriptionSuccess {
  success: true
  text: string
  words?: TranscriptWord[] | undefined
  utterances?: BatchUtterance[] | undefined
  speakers?: Array<{ id: string; name?: string | undefined }> | undefined
  summary?: string | undefined
  language?: string | undefined
  processingTimeMs: number
  providerJobId?: string | undefined
  audioDuration?: number | undefined
  rawProviderResponse?: unknown | undefined
}

/**
 * Failed batch transcription result
 */
export interface BatchTranscriptionFailure {
  success: false
  error: { code: string; message: string; httpStatus?: number | undefined; responseMessage?: string | undefined }
  processingTimeMs?: number | undefined
}

/**
 * Discriminated union for type-safe batch transcription result handling
 */
export type BatchTranscriptionResult = BatchTranscriptionSuccess | BatchTranscriptionFailure

/**
 * Providers that support webhook-based (fire-and-forget) batch transcription.
 * Other providers fall back to blocking inline transcription.
 */
export type WebhookProvider = "gladia" | "assemblyai" | "deepgram" | "speechmatics" | "soniox"
export const WEBHOOK_PROVIDERS = new Set<string>(["gladia", "assemblyai", "deepgram", "speechmatics", "soniox"])

/**
 * Result of submitting a batch transcription job with a webhook callback URL.
 * The provider will call the webhook when transcription completes.
 */
export interface SubmitBatchResult {
  providerJobId: string
}
