/**
 * Providers that support post-meeting batch transcription (webhook pipeline).
 * Single source of truth — all other provider lists derive from this.
 */
export const BATCH_PROVIDERS = [
  "gladia",
  "deepgram",
  "assemblyai",
  "speechmatics",
  "soniox"
] as const

export type BatchProvider = (typeof BATCH_PROVIDERS)[number]

/**
 * Providers that support real-time streaming (batch providers + streaming-only)
 */
export const STREAMING_PROVIDERS = [
  ...BATCH_PROVIDERS,
  "elevenlabs"
] as const

export type StreamingProvider = (typeof STREAMING_PROVIDERS)[number]

/**
 * All supported transcription providers (batch + streaming)
 */
export const PROVIDERS = STREAMING_PROVIDERS

export type Provider = StreamingProvider

/**
 * Human-readable display names for each provider.
 */
export const PROVIDER_DISPLAY_NAMES: Record<Provider, string> = {
  gladia: "Gladia",
  deepgram: "Deepgram",
  assemblyai: "AssemblyAI",
  speechmatics: "Speechmatics",
  soniox: "Soniox",
  elevenlabs: "ElevenLabs"
}

/**
 * Mapping from provider name strings to SDK provider names.
 */
export const PROVIDER_NAME_MAP: Record<string, StreamingProvider> = {
  gladia: "gladia",
  deepgram: "deepgram",
  assemblyai: "assemblyai",
  speechmatics: "speechmatics",
  soniox: "soniox",
  elevenlabs: "elevenlabs"
}

/**
 * Resolve a provider name from the BotMessage value to a StreamingProvider.
 * Returns undefined if the name is not a known provider (e.g. "none").
 */
export function resolveProviderName(name: string): StreamingProvider | undefined {
  return PROVIDER_NAME_MAP[name]
}

/**
 * Environment variable name for a provider's API key.
 * Maps each provider to its expected env var name.
 */
export const PROVIDER_ENV_KEY_MAP: Record<StreamingProvider, string> = {
  gladia: "GLADIA_API_KEY",
  deepgram: "DEEPGRAM_API_KEY",
  assemblyai: "ASSEMBLYAI_API_KEY",
  speechmatics: "SPEECHMATICS_API_KEY",
  soniox: "SONIOX_API_KEY",
  elevenlabs: "ELEVENLABS_API_KEY"
}

/**
 * API key configuration for per-request usage
 */
export interface ApiKeyConfig {
  apiKey: string
}

/**
 * Minimal logger interface compatible with pino / Fastify loggers.
 * Consumers pass their own logger; the package never imports a logging library.
 */
export interface Logger {
  info(obj: Record<string, unknown>, msg: string): void
  warn(obj: Record<string, unknown>, msg: string): void
  error(obj: Record<string, unknown>, msg: string): void
}

/**
 * Console-based fallback used when no logger is injected.
 */
export const defaultLogger: Logger = {
  info: (obj, msg) => console.log(`[voice-router] ${msg}`, obj),
  warn: (obj, msg) => console.warn(`[voice-router] ${msg}`, obj),
  error: (obj, msg) => console.error(`[voice-router] ${msg}`, obj)
}

/**
 * Individual word with timing and confidence
 */
export interface TranscriptWord {
  text: string
  start: number
  end: number
  confidence?: number | undefined
  speaker?: string | undefined
}
