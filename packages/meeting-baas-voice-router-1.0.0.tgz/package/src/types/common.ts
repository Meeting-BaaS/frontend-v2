/**
 * SDK-derived runtime types and builder functions.
 *
 * This module re-exports frontend-safe constants from `./providers-public`
 * and adds SDK-dependent types (discriminated unions, region maps, defaults,
 * builder functions) that belong on the server/runtime side.
 *
 * Frontend consumers should use the `@meeting-baas/voice-router/providers`
 * subpath which routes through `providers-public.ts` without touching the SDK.
 */

// ─── Re-export frontend-safe constants (single source of truth) ──────

export {
  BATCH_PROVIDERS,
  STREAMING_PROVIDERS,
  PROVIDERS,
  PROVIDER_DISPLAY_NAMES,
  BATCH_PROVIDER_REGIONS,
  STREAMING_PROVIDER_REGIONS
} from "./providers-public"
export type { BatchProvider, StreamingProvider, Provider } from "./providers-public"

// Also import for local use in builders and type definitions
import type { StreamingProvider } from "./providers-public"
import { BATCH_PROVIDER_REGIONS, STREAMING_PROVIDER_REGIONS } from "./providers-public"

// ─── Runtime helpers (not needed by frontends) ───────────────────────

/**
 * Mapping from provider name strings to SDK provider names.
 */
export const PROVIDER_NAME_MAP: Record<string, StreamingProvider> = {
  gladia: "gladia",
  deepgram: "deepgram",
  assemblyai: "assemblyai",
  speechmatics: "speechmatics",
  soniox: "soniox",
  elevenlabs: "elevenlabs"
}

/**
 * Resolve a provider name from the BotMessage value to a StreamingProvider.
 * Returns undefined if the name is not a known provider (e.g. "none").
 */
export function resolveProviderName(name: string): StreamingProvider | undefined {
  return PROVIDER_NAME_MAP[name]
}

/**
 * Environment variable name for a provider's API key.
 * Maps each provider to its expected env var name.
 */
export const PROVIDER_ENV_KEY_MAP: Record<StreamingProvider, string> = {
  gladia: "GLADIA_API_KEY",
  deepgram: "DEEPGRAM_API_KEY",
  assemblyai: "ASSEMBLYAI_API_KEY",
  speechmatics: "SPEECHMATICS_API_KEY",
  soniox: "SONIOX_API_KEY",
  elevenlabs: "ELEVENLABS_API_KEY"
}

// ─── SDK imports (runtime-only) ──────────────────────────────────────

import {
  DeepgramRegion,
  AssemblyAIRegion,
  SpeechmaticsRegion,
  SonioxRegion,
  GladiaRegion,
  ElevenLabsRegion
} from "voice-router-dev"

/** Extract value tuple from a `{ readonly key: value }` const object. */
type ValuesOf<T> = T[keyof T]

/**
 * Default regions used when no explicit region is provided.
 * Values are SDK constants — the `satisfies` constraint ensures they stay
 * within the allowed region set from providers-public.
 */
export const DEFAULT_BATCH_REGION = {
  deepgram: DeepgramRegion.eu,
  assemblyai: AssemblyAIRegion.eu,
  speechmatics: SpeechmaticsRegion.eu1,
  soniox: SonioxRegion.us
} as const satisfies { [K in keyof typeof BATCH_PROVIDER_REGIONS]: (typeof BATCH_PROVIDER_REGIONS)[K][number] }

// ─── Provider-discriminated API key configs ──────────────────────────

/**
 * Region types per provider for batch transcription.
 */
export type BatchProviderRegionMap = {
  deepgram: ValuesOf<typeof DeepgramRegion>
  assemblyai: ValuesOf<typeof AssemblyAIRegion>
  speechmatics: ValuesOf<typeof SpeechmaticsRegion>
  soniox: ValuesOf<typeof SonioxRegion>
}

/**
 * Region types per provider for streaming transcription.
 * Includes all providers in {@link STREAMING_PROVIDER_REGIONS}.
 */
export type StreamingProviderRegionMap = {
  gladia: ValuesOf<typeof GladiaRegion>
  deepgram: ValuesOf<typeof DeepgramRegion>
  assemblyai: ValuesOf<typeof AssemblyAIRegion>
  speechmatics: ValuesOf<typeof SpeechmaticsRegion>
  soniox: ValuesOf<typeof SonioxRegion>
  elevenlabs: ValuesOf<typeof ElevenLabsRegion>
}

/**
 * Discriminated union of API key configs for batch transcription.
 * Provider is the discriminant — region types are provider-specific.
 * Gladia has no region field (no batch region concept).
 */
export type BatchApiKeyConfig =
  | { provider: "gladia"; apiKey: string }
  | { provider: "deepgram"; apiKey: string; region: BatchProviderRegionMap["deepgram"] }
  | { provider: "assemblyai"; apiKey: string; region: BatchProviderRegionMap["assemblyai"] }
  | { provider: "speechmatics"; apiKey: string; region: BatchProviderRegionMap["speechmatics"] }
  | { provider: "soniox"; apiKey: string; region: BatchProviderRegionMap["soniox"] }

/**
 * Discriminated union of API key configs for streaming transcription.
 * All streaming providers carry a region — for gladia, it flows to streaming
 * options (not the adapter), for elevenlabs it flows to the adapter config.
 */
export type StreamingApiKeyConfig =
  | { provider: "gladia"; apiKey: string; region: StreamingProviderRegionMap["gladia"] }
  | { provider: "deepgram"; apiKey: string; region: StreamingProviderRegionMap["deepgram"] }
  | { provider: "assemblyai"; apiKey: string; region: StreamingProviderRegionMap["assemblyai"] }
  | { provider: "speechmatics"; apiKey: string; region: StreamingProviderRegionMap["speechmatics"] }
  | { provider: "soniox"; apiKey: string; region: StreamingProviderRegionMap["soniox"] }
  | { provider: "elevenlabs"; apiKey: string; region: StreamingProviderRegionMap["elevenlabs"] }

/**
 * Default regions for streaming transcription.
 * Same providers/values as {@link DEFAULT_BATCH_REGION} — deepgram/assemblyai/speechmatics/soniox
 * share SDK region types across batch and streaming.
 */
export const DEFAULT_STREAMING_REGION = {
  gladia: GladiaRegion["eu-west"],
  deepgram: DeepgramRegion.eu,
  assemblyai: AssemblyAIRegion.eu,
  speechmatics: SpeechmaticsRegion.eu1,
  soniox: SonioxRegion.us,
  elevenlabs: ElevenLabsRegion.global
} as const satisfies { [K in keyof StreamingProviderRegionMap]: StreamingProviderRegionMap[K] }

// ─── Builder functions ───────────────────────────────────────────────

/**
 * Build a typed {@link BatchApiKeyConfig} from loose string inputs (DB/SQS boundary).
 * Returns `null` if the provider is unknown, not a batch provider, or the
 * explicitly-supplied region is invalid.
 *
 * When `region` is `null`/`undefined`, the default from {@link DEFAULT_BATCH_REGION}
 * is used. When `region` is a non-null string that isn't in the provider's allowed
 * set, `null` is returned so callers can surface the error.
 */
export function buildBatchApiKeyConfig(
  provider: string,
  apiKey: string,
  region: string | null | undefined
): BatchApiKeyConfig | null {
  switch (provider) {
    case "gladia":
      return { provider: "gladia", apiKey }
    case "deepgram": {
      if (region != null && !(BATCH_PROVIDER_REGIONS.deepgram as readonly string[]).includes(region)) return null
      return { provider: "deepgram", apiKey, region: (region ?? DEFAULT_BATCH_REGION.deepgram) as BatchProviderRegionMap["deepgram"] }
    }
    case "assemblyai": {
      if (region != null && !(BATCH_PROVIDER_REGIONS.assemblyai as readonly string[]).includes(region)) return null
      return { provider: "assemblyai", apiKey, region: (region ?? DEFAULT_BATCH_REGION.assemblyai) as BatchProviderRegionMap["assemblyai"] }
    }
    case "speechmatics": {
      if (region != null && !(BATCH_PROVIDER_REGIONS.speechmatics as readonly string[]).includes(region)) return null
      return { provider: "speechmatics", apiKey, region: (region ?? DEFAULT_BATCH_REGION.speechmatics) as BatchProviderRegionMap["speechmatics"] }
    }
    case "soniox": {
      if (region != null && !(BATCH_PROVIDER_REGIONS.soniox as readonly string[]).includes(region)) return null
      return { provider: "soniox", apiKey, region: (region ?? DEFAULT_BATCH_REGION.soniox) as BatchProviderRegionMap["soniox"] }
    }
    default:
      return null
  }
}

/**
 * Build a typed {@link StreamingApiKeyConfig} from loose string inputs (DB/SQS boundary).
 * Returns `null` if the provider is unknown or the explicitly-supplied region is invalid.
 *
 * When `region` is `null`/`undefined`, the default from {@link DEFAULT_STREAMING_REGION}
 * is used. When `region` is a non-null string that isn't in the provider's allowed
 * set, `null` is returned so callers can surface the error.
 */
export function buildStreamingApiKeyConfig(
  provider: string,
  apiKey: string,
  region: string | null | undefined
): StreamingApiKeyConfig | null {
  switch (provider) {
    case "gladia": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.gladia as readonly string[]).includes(region)) return null
      return { provider: "gladia", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.gladia) as StreamingProviderRegionMap["gladia"] }
    }
    case "elevenlabs": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.elevenlabs as readonly string[]).includes(region)) return null
      return { provider: "elevenlabs", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.elevenlabs) as StreamingProviderRegionMap["elevenlabs"] }
    }
    case "deepgram": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.deepgram as readonly string[]).includes(region)) return null
      return { provider: "deepgram", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.deepgram) as StreamingProviderRegionMap["deepgram"] }
    }
    case "assemblyai": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.assemblyai as readonly string[]).includes(region)) return null
      return { provider: "assemblyai", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.assemblyai) as StreamingProviderRegionMap["assemblyai"] }
    }
    case "speechmatics": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.speechmatics as readonly string[]).includes(region)) return null
      return { provider: "speechmatics", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.speechmatics) as StreamingProviderRegionMap["speechmatics"] }
    }
    case "soniox": {
      if (region != null && !(STREAMING_PROVIDER_REGIONS.soniox as readonly string[]).includes(region)) return null
      return { provider: "soniox", apiKey, region: (region ?? DEFAULT_STREAMING_REGION.soniox) as StreamingProviderRegionMap["soniox"] }
    }
    default:
      return null
  }
}

// ─── Shared interfaces ───────────────────────────────────────────────

/**
 * Minimal logger interface compatible with pino / Fastify loggers.
 * Consumers pass their own logger; the package never imports a logging library.
 */
export interface Logger {
  info(obj: Record<string, unknown>, msg: string): void
  warn(obj: Record<string, unknown>, msg: string): void
  error(obj: Record<string, unknown>, msg: string): void
}

/**
 * Console-based fallback used when no logger is injected.
 */
export const defaultLogger: Logger = {
  info: (obj, msg) => console.log(`[voice-router] ${msg}`, obj),
  warn: (obj, msg) => console.warn(`[voice-router] ${msg}`, obj),
  error: (obj, msg) => console.error(`[voice-router] ${msg}`, obj)
}

/**
 * Individual word with timing and confidence
 */
export interface TranscriptWord {
  text: string
  start: number
  end: number
  confidence?: number | undefined
  speaker?: string | undefined
}
