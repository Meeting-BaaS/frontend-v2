/**
 * Drift-detection test: asserts that the hardcoded region arrays in
 * providers-public.ts match the SDK region enum values at runtime.
 *
 * If an SDK upgrade adds/removes/renames a region, this test will fail,
 * prompting an update to providers-public.ts so the frontend stays in sync.
 */
import { describe, it, expect } from "vitest"
import {
  DeepgramRegion,
  AssemblyAIRegion,
  SpeechmaticsRegion,
  SonioxRegion,
  GladiaRegion,
  ElevenLabsRegion
} from "voice-router-dev"
import {
  BATCH_PROVIDER_REGIONS,
  STREAMING_PROVIDER_REGIONS
} from "@/types/providers-public"

describe("providers-public region drift detection", () => {
  it("BATCH_PROVIDER_REGIONS.deepgram matches SDK DeepgramRegion", () => {
    expect([...BATCH_PROVIDER_REGIONS.deepgram].sort()).toEqual(Object.values(DeepgramRegion).sort())
  })

  it("BATCH_PROVIDER_REGIONS.assemblyai matches SDK AssemblyAIRegion", () => {
    expect([...BATCH_PROVIDER_REGIONS.assemblyai].sort()).toEqual(Object.values(AssemblyAIRegion).sort())
  })

  it("BATCH_PROVIDER_REGIONS.speechmatics matches SDK SpeechmaticsRegion", () => {
    expect([...BATCH_PROVIDER_REGIONS.speechmatics].sort()).toEqual(Object.values(SpeechmaticsRegion).sort())
  })

  it("BATCH_PROVIDER_REGIONS.soniox matches SDK SonioxRegion", () => {
    expect([...BATCH_PROVIDER_REGIONS.soniox].sort()).toEqual(Object.values(SonioxRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.gladia matches SDK GladiaRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.gladia].sort()).toEqual(Object.values(GladiaRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.deepgram matches SDK DeepgramRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.deepgram].sort()).toEqual(Object.values(DeepgramRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.assemblyai matches SDK AssemblyAIRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.assemblyai].sort()).toEqual(Object.values(AssemblyAIRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.speechmatics matches SDK SpeechmaticsRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.speechmatics].sort()).toEqual(Object.values(SpeechmaticsRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.soniox matches SDK SonioxRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.soniox].sort()).toEqual(Object.values(SonioxRegion).sort())
  })

  it("STREAMING_PROVIDER_REGIONS.elevenlabs matches SDK ElevenLabsRegion", () => {
    expect([...STREAMING_PROVIDER_REGIONS.elevenlabs].sort()).toEqual(Object.values(ElevenLabsRegion).sort())
  })
})
